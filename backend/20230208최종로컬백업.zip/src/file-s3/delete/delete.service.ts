import { Injectable, Param, Post } from '@nestjs/common';

@Injectable()
export class DeleteService {
    constructor(){}

   
    deleteFile(s3filename: string){
        
    }
}
