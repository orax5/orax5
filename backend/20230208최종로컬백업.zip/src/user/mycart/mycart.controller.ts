import { Controller } from '@nestjs/common';

@Controller('user-mycart')
export class UserCartController {

}
