// const tmp = [
//     {
//         "shin_no": 1,
//         "shin_title": "1번 노래",
//         "shin_amount": 10,
//         "shin_nft_totalbalance": 100,
//         "shin_cover": "https://img1.daumcdn.net/thumb/R1280x0.fjpg/?fname=http://t1.daumcdn.net/brunch/service/user/7PBF/image/b0KVeRRLDeOtIap0-KnApW1uW8Q",
//         "shin_opendate": "2023-02-08",
//         "shin_description": "트로르 감성의 노래_1",
//         "shin_category": "트로트",
//         "shin_ispermit": 2,
//         "shin_creator_address": "0x123qwe123qwe",
//         "singer": [
//             {
//                 "sing_name": "하진가수1"
//             }
//         ],
//         "composer": [
//             {
//                 "com_name": "작곡가1"
//             }
//         ],
//         "lyricist": [
//             {
//                 "lyric_name": "작사가1"
//             }
//         ]
//     }
// ]

// const [ { singer:[{sing_name}] } ] = tmp
// console.log(sing_name)

